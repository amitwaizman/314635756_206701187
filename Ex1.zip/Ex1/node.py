
#A class that contains a floor when the elevator arrives and the reading direction.
class node:
    def __init__(self, floor, time, direction) -> None:
        self.floor = floor
        self.time = time
        self.direction = direction
