
class Allocation:

    def __init__(self, route, startIndex, endIndex) -> None:
        self.route = route
        self.startIndex = startIndex
        self.endIndex = endIndex